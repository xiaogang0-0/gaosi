﻿1、index  优化修改密码面板
2、新增账户管理页面  zhgl_zhanghuguanli.html
3、教务教学-1对1班级管理 页面优化   jwjx_ydybanjiguanli.html
4、教务教学-班组课班级管理 页面优化   jwjx_bzkbanjiguanli.html
5、教务教学-学员中心 页面优化   jwjx_xueyuanzhongxin.html
6、日期插件更换
  需要在页面底部引入
  <script src="js/datetimepicker/jquery.datetimepicker.full.js"></script>
  样式引入
  <link rel="stylesheet" href="js/datetimepicker/jquery.datetimepicker.min.css">
7、人员管理--教师管理--添加教师  rygl_jiaoshiguanli.html
8、人员管理--校区人员管理--添加人员  rygl_xiaoqurenyuanguanli.html
9、系统设置--资源渠道   增加“测评”   xtsz_ziyuanqudao.html
10、前台业务--办理报名   qtyw_shoucibaoming.html
10、前台业务--账户充值--添加二维码   qtyw_xueyuanjifei.html
